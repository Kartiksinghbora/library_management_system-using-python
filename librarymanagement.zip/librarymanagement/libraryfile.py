from library import *

def main():
    lb=library()
    lib={}
    db=input("enter database name")
    if db == "library_management_system":
        print("1. Add Book")
        print("2. Search Book")
        print("3. Delete Book")
        print("4. Show Book")
        print("5. Issue Book")
        print("6. Return Book")
        print("7. Show Customers")
        print("8. Exit Library")
    
        while True:
        
            choice=input("Enter your choice")
            
            if choice=="1":
                lb.add_book(lib)
                
            elif choice=="2":
                lb.search_book(lib)

            elif choice=="3":
                lb.delete_book(lib)
            
            elif choice=="4":
                lb.show_book(lib)

            elif choice=="5":
                lb.issue_book(lib)

            elif choice=="6":
                lb.return_book(lib)

            elif choice=="7":
                lb.show_customers(lib)
                
            elif choice=="8":
                lb.exit_library(lib)

            else:
                print("wrong input")

            
    else:
        print("database not found")


if __name__ == "__main__":
    main()
