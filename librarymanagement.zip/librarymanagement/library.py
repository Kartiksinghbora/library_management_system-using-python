import mysql.connector
from datetime import datetime 
from prettytable import PrettyTable

class library:

    def __init__(self):
        
        self.myconn=mysql.connector.connect(host="localhost",user="root",passwd="",database="library_management_system")
        self.mycur=self.myconn.cursor();


    def add_book(self, lib):
        self.book_name = input("Enter book name: ")
        self.author_name = input("Enter author name: ")
        self.book_price = input("Enter book price: ")
        self.quantity = int(input("Enter quantity: "))

        check_query = "select quantity from library where book_name = %s"
        self.mycur.execute(check_query, (self.book_name,))
        result = self.mycur.fetchone()

        if result:
            current_quantity = result[0]
            new_quantity = current_quantity + self.quantity
            update_query = "update library set quantity = %s where book_name = %s"
            try:
                self.mycur.execute(update_query, (new_quantity, self.book_name))
                self.myconn.commit()
                print(f"The quantity of '{self.book_name}' updated to {new_quantity}.")
            except Exception as e:
                self.myconn.rollback()
                print("An error occurred while updating the book quantity:", e)
        else:
            insert_query = "insert into library(book_name,author_name,book_price,quantity) values (%s,%s,%s,%s)"
            val = (self.book_name, self.author_name, self.book_price, self.quantity)
            try:
                self.mycur.execute(insert_query, val)
                self.myconn.commit()
                print("Book added successfully")
            except Exception as e:
                self.myconn.rollback()
                print("An error occurred while adding the book:", e)




    def search_book(self,lib):
        self.book_name=input("enter book name you want to search")


        try:
            check_query="select * from library where book_name=%s"
            self.mycur.execute(check_query,(self.book_name,))
            result=self.mycur.fetchall()

            if result:
                for x in result:
                    print(x)

            else:
                print("book not found in library")

        except:
            self.myconn.rollback()


    def delete_book(self,lib):
        self.book_name=input("enter book name you want to delete")

        try:
            check_query="delete from library where book_name=%s"
            val=(self.book_name,)

            self.mycur.execute(check_query,val)
            self.myconn.commit()
            print(self.book_name," deleted from the library")

        except:
            self.myconn.rollback()


    def show_book(self,lib):

        try:
            show_query="select * from library"
            self.mycur.execute(show_query)
            result=self.mycur.fetchall()
        
            if result:
                for x in result:
                    print(x)

            else:
                print("library is empty")

        except:
            self.myconn.rollback()



  

    def issue_book(self, lib):
        self.book_name = input("Enter book name: ")
        self.quantity = int(input("Enter quantity: "))

        try:
            check_query = "select quantity from library where book_name = %s"
            self.mycur.execute(check_query, (self.book_name,))
            result = self.mycur.fetchone()

            if result:
                security_amt = 1000
                security_amt2 = 1500
                current_quantity = result[0]
                print(f"The current quantity of '{self.book_name}' is {current_quantity}.")

                if current_quantity == 0:
                    print("Book not available in the library")
                else:
                    if self.quantity == 1:
                        print("You have to pay: ", security_amt)
                    elif self.quantity == 2:
                        print("You have to pay: ", security_amt2)
                    else:
                        print("You are not allowed to issue more than 2 books")
                        return

                    self.customer_name = input("Enter customer name: ")
                    self.customer_mobile = input("Enter customer mobile number: ")
                    self.days = int(input("Enter days: "))
                    self.date = input("Issue date (YYYY-MM-DD): ")
                    self.customer_add = input("Enter customer address: ")

                    try:
                        issue_date = datetime.strptime(self.date, '%Y-%m-%d').date()
                    except ValueError:
                        print("Incorrect date format. Please enter the date in YYYY-MM-DD format.")
                        return

                    security_amt_to_pay = security_amt if self.quantity == 1 else security_amt2

                    insert_query = "insert into customer(book_name,customer_name,customer_mobile,days,quantity,security_amt,customer_add,issue_date) values (%s,%s,%s,%s,%s,%s,%s,%s)"
                    val = (self.book_name, self.customer_name, self.customer_mobile, self.days, self.quantity, security_amt_to_pay, self.customer_add, issue_date)
                    self.mycur.execute(insert_query, val)
                    self.myconn.commit()
                    print("\nBook issued successfully to ", self.customer_name)

                    output = current_quantity - self.quantity
                    update_query = "update library set quantity = %s where book_name = %s"
                    value1 = (output, self.book_name)
                    self.mycur.execute(update_query, value1)
                    self.myconn.commit()
            else:
                print(f"The book '{self.book_name}' is not available in the library.")

        except Exception as e:
            self.myconn.rollback()
            print("An error occurred:", e)


 

    def return_book(self, lib):
        self.customer_name = input("Enter customer name: ")
        self.book_name = input("Enter book name: ")

        show_query = "select * from customer where book_name = %s and customer_name = %s"
        val = (self.book_name, self.customer_name)
        self.mycur.execute(show_query, val)
        result = self.mycur.fetchone()

        if result:
            issue_date = result[8]
            print(self.customer_name," issue this book on ",issue_date)
            sec_amt = result[6]
            print("total security amount ",sec_amt)
            total_days = result[4]

            current_date = datetime.now().date()
            days_issued = (current_date - issue_date).days

            penalty = 0
            if days_issued > total_days:
                penalty = 10 * (days_issued - total_days)

            refund_amount = sec_amt - penalty
            print(f"Days issued: {days_issued}")
            print(f"Penalty: {penalty}")
            print(f"Refund amount: {refund_amount}")

            table = PrettyTable()
            column_names = [desc[0] for desc in self.mycur.description]
            table.field_names = column_names
            table.add_row(result)

            print(table)

            update_query = "update library set quantity = quantity + %s where book_name = %s"
            self.mycur.execute(update_query, (result[5], self.book_name))


            delete_query = "delete from customer where book_name = %s and customer_name = %s"
            self.mycur.execute(delete_query, val)

            self.myconn.commit()
            print(f"Book returned successfully by {self.customer_name}. Refund amount: {refund_amount}")
        else:
            print(f"No record found for {self.customer_name} with the book {self.book_name}.")




    def show_customers(self, lib):
        show_query = "select * from customer"
        self.mycur.execute(show_query)
        result = self.mycur.fetchall()

        if result:
            table = PrettyTable()
            column_names = [desc[0] for desc in self.mycur.description]
            table.field_names = column_names
        
            for row in result:
                table.add_row(row)

            print(table)
        else:
            print("No customers found.")


                       
    def exit_library(self,lib):
        self.myconn.close();


        

        
        
        
        
            

            

            

                            
                

            
        
            

       


    
